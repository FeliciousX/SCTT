<div class="row">
  <div class="footer">
    <strong><?php echo anchor('admin', '&copy;', 'class=plain'); ?> 2013 Straits Central Travel &amp; Tour Agencies. All rights reserved.</strong> &nbsp; <a class="underline" href="<?php echo base_url('/about'); ?>">About Us</a><br />
    No. 123, Lot 41, Section 33, Tabuan Road, 93100 Kuching, Sarawak, Malaysia <br/>
    Tel : +6082-242-295 / 241-271 <br />
    Fax : +6082-235-122 / 240-713 <br />
  </div>
</div>

</div> <!-- End of div.container -->

<!-- javascript
    ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
    <script src="<?php echo base_url('js/jquery.js'); ?>"></script>
    <script src="<?php echo base_url('js/bootstrap.min.js'); ?>"></script>
    <script src="<?php echo base_url('js/bootstrap-datepicker.js'); ?>"></script>
    <script>
      !function ($) {
        $(function(){
          // carousel demo
          $('#myCarousel').carousel()
        })
      }(window.jQuery)
    </script>
    <script>$('.date').datepicker()</script>
</body>
</html>