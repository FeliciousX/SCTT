<?php

/**
 * Installer Controller
 *
 * @package		QuickSnaps
 * @subpackage	Installer
 * @author		Eoin McGrath
 * @link		http://www.starfishwebconsulting.co.uk/quicksnaps
 */
class Install_Controller extends MY_Controller {


}

