<div class="info">
	<p>Your password has been changed</p>
</div>

