<div class="info">

    <h3>
        Welcome to QuickSnaps
    </h3>

    <p>
        To create an album click the <i>Create New Album</i> link above.
    </p>


    <p>
        You can change the name and description of your gallery in the <i>Settings</i> tab
    </p>


    <p>
        Don't like the default theme? You can change it or even add new ones. Click the <i>Themes</i> tab for more
    </p>

</div>
